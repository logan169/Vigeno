__author__ = 'schwartzl'

import pyGeno.bootstrap as B

B.printDatawraps()
B.importSNPs('human_9606_b146_GRCh37p13_common_all_20151104.tar.gz')
